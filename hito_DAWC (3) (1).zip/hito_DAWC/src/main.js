
import './app/registroForm.js';
import './app/loginForm.js';
import './app/googleLogin.js'; // Corregido: Sin espacio antes de la barra
import './app/reserva.js';
console.log('hello world');



